%% vitDecode: Perform Viterbi decoding on Trellis = poly2trellis(3,[7,5])
% output: decoded = decoded sequence
% Inputs: encoded = encoded sequence with Trellis = poly2trellis(3,[7,5])
function decoded = vitDecode(encoded)

%% Compute weight matrix to represent branch metrics
decodedLen = length(encoded) / 2;
weightMatrix = zeros(8, decodedLen);

for i = 1 : 8
    for j = 1 : decodedLen
        receivedBits = encoded(2 * j - 1: 2 * j);
        expectedBits = [0 0; 1 1; 1 1; 0 0; 1 0; 0 1; 0 1; 1 0];
        weightMatrix(i, j) = ...
            computeDistance(receivedBits, expectedBits(i, :));
    end
end

%% Compute cost matrix to represent the cost of reaching each state
costMatrix = zeros(4, decodedLen + 1);
costMatrix(2 : 4, 1) = 10000;  % start with 00
for col = 2 : decodedLen + 1
    for row = 1 : 4
        if row == 1
            cost = [costMatrix(1, col - 1) + weightMatrix(1, col - 1), ...
                costMatrix(3, col - 1) + weightMatrix(2, col - 1)];
            costMatrix(row, col) = min(cost);
        end
        if row == 2
            cost = [costMatrix(1, col - 1) + weightMatrix(3, col - 1), ...
                costMatrix(3, col - 1) + weightMatrix(4, col - 1)];
            costMatrix(row, col) = min(cost);
        end
        if row == 3
            cost = [costMatrix(2, col - 1) + weightMatrix(5, col - 1), ...
                costMatrix(4, col - 1) + weightMatrix(6, col - 1)];
            costMatrix(row, col) = min(cost);
        end
        if row == 4
            cost = [costMatrix(2, col - 1) + weightMatrix(7, col - 1), ...
                costMatrix(4, col - 1) + weightMatrix(8, col - 1)];
            costMatrix(row, col) = min(cost);
        end
    end
end

%% Trackback to find shortest codePath
codePath = zeros(1, decodedLen + 1);
[~, index] = min(costMatrix(:, decodedLen + 1));
codePath(decodedLen + 1) = index;
for col = decodedLen + 1 : -1:  2
    if codePath(col) == 1
        if costMatrix(1, col) - weightMatrix(1, col - 1) ...
                == costMatrix(1, col - 1)
            codePath(col - 1) = 1;
        else
            codePath(col - 1) = 3;
        end
    elseif codePath(col) == 2
        if costMatrix(2, col) - weightMatrix(3, col - 1) ...
                == costMatrix(1, col - 1)
            codePath(col - 1) = 1;
        else
            codePath(col - 1) = 3;
        end
    elseif codePath(col) == 3
        if costMatrix(3, col) - weightMatrix(5, col - 1) ...
                == costMatrix(2, col - 1)
            codePath(col - 1) = 2;
        else
            codePath(col - 1) = 4;
        end
    elseif codePath(col) == 4
        if costMatrix(4, col) - weightMatrix(7, col - 1) ...
                == costMatrix(2, col - 1)
            codePath(col - 1) = 2;
        else
            codePath(col - 1) = 4;
        end
    end
    
end
%% Decode using the codePath
decoded = zeros(1, decodedLen);
for i = 1 : length(codePath) - 1
    if codePath(i) == 1
        if codePath(i + 1) == 1
            decoded(i) = 0;
        else
            decoded(i) = 1;
        end
    elseif codePath(i) == 2
        if codePath(i + 1) == 3
            decoded(i) = 0;
        else
            decoded(i) = 1;
        end
    elseif codePath(i) == 3
        if codePath(i + 1) == 1
            decoded(i) = 0;
        else
            decoded(i) = 1;
        end
    elseif codePath(i) == 4
        if codePath(i + 1) == 3
            decoded(i) = 0;
        else
            decoded(i) = 1;
        end
    end
end
end

%% computeDistance: Compute the distance on received and expected arrays
function distance = computeDistance(received, expected)
distance = sum(abs(received - expected).^2);
end









