%% wifireceiver: Decodes a received Wi-Fi packet
% outputs: message = decoded message, len = message length, start = number
% of padded zeros before the packet
% Inputs: txsignal = received wifi packet, level = number of stages of 
% decoding
function [message, len, start] = wifireceiver(txsignal, level)
    %% Default values and sanity checks
    symLen = 128;
    
    if (nargin < 2)
        level = 5;
    end
    
    if(level > 5 || level < 1)
        fprintf(2, 'Error: Invalid level, must be 1-5\n');  %2 for standard error
        message = []; len = 0; start = 0;
        return;
    end
    %% Layer #1: Preamble detection
    if (level == 5)
        preamble = [1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1,1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1];
        preamble_symbols = fft(qammod(preamble.',4,'InputType','bit'));
        % Detect preamble using a sliding window to find the most possible
        % sequence position
        similarity = zeros(1, length(txsignal) - 128);
        for i = 1 : length(similarity)
            similarity(i) = sum(abs(preamble_symbols ...
                - txsignal(i : i + 63)).^2);
        end
        [~, index] = min(similarity);  % index for start of preamble
        start = index - 1;  % length of padded zeros before packet
        
        % Decode the message length first
        txsignal = txsignal(index : end);  % chop the 0s at the begining
        len = txsignal(65 : 128);  % encoded length bits
        len = ifft(len);
        len = qamdemod(len, 4, 'OutputType', 'bit').';
        len = num2str(len);  % no convenc on length bits
        len = bin2dec(len(end - 15 : end));  % % Message length < 10000, then bit length < 16
        % Chop the 0s at the end of the packet
        nsymbol = ceil(len / 16);
        txsignal = txsignal(1 : 128 + 128 * nsymbol);
    end
    
    %% Layer #2: Reverse OFDM on every 64 data point
    if (level >= 4)
        for i = 1 : length(txsignal) / 64
            reversed = ifft(txsignal((i - 1) * 64 + 1 : i * 64));
            txsignal((i - 1) * 64 + 1 : i * 64) = reversed;
        end
    end
    
    %% Layer #3: 4-QAM demodulation
    if (level >= 3)
        txsignal = qamdemod(txsignal, 4, 'OutputType', 'bit').';
        % Discard the preamble bits
        txsignal = txsignal(symLen + 1 : end);
    end
    
    %% Layer #4: Viterbi decoding
    if (level >= 2)
        encoded = txsignal(symLen + 1 : end);  % length bits not encoded
        decoded = vitDecode(encoded);
        txsignal = [txsignal(1 : symLen), decoded];
    end
    
    %% Layer #5: Undo interleaving
    if (level >= 1)
        message = [];
        revInterleave = reshape(reshape([1:symLen], 32, 4).', [], 1);
        
        % Message length < 10000, then bit length < 16
        binLen = num2str(txsignal(symLen - 15 : symLen));
        len = bin2dec(binLen);
        
        nsym = length(txsignal) / symLen - 1;
        count = len;
        for i = 1 : nsym
            symbol = txsignal(i * symLen + 1: i * symLen + symLen);
            symbol = symbol(revInterleave);
            % 16 characters make up for one symbol (256 bits)
            if (count > 16)
                count = count - 16;
                for j = 1 : 16
                    c = bin2dec(num2str(symbol((j - 1)*8 + 1: j * 8)));
                    message = [message, char(c)];
                end
            else
                for j = 1 : count
                    c = bin2dec(num2str(symbol((j - 1)*8 + 1: j * 8)));
                    message = [message, char(c)];
                end
            end
        end
        
        nsym
        message
        
    end
end

