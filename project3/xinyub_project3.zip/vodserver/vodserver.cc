#include <iostream>
#include <string>
#include <sstream>
#include <ctime>
#include <vector>

#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>

using namespace std;

const int MAX_CHUNKSIZE = 5 * (1 << 20); // 5MB

// Returns a timestamp string given a time value
string getTimestamp(time_t t)
{
    tm *gmtm = gmtime(&t);
    char buffer[80];

    strftime(buffer, 80, "%a, %d %b %Y %H:%M:%S GMT", gmtm);

    return string(buffer);
}

// Invoked when a thread exit to close the socket
void closeConnFd(void *pArg) {
    int connFd = *(int *)pArg;
    close(connFd);

    cout << "---Old connection socket closed, old connFd = " + to_string(connFd) + "---" 
         << endl << endl;
}

// Splits a string with a given delimiter
vector<string> splitWithStl(string &str,const string &pattern)
{
    vector<std::string> resVec;

	if ("" == str)
    {
        return resVec;
    }
    
    string strs = str + pattern;
    
    size_t pos = strs.find(pattern);
    size_t size = strs.size();

    while (pos != string::npos)
    {
        string x = strs.substr(0,pos);
        resVec.push_back(x);
        strs = strs.substr(pos+1,size);
        pos = strs.find(pattern);
    }
    
    return resVec;
}

// Functionalitie of http handling threads
void *threadFunc(void *pArg)
{
    int connFd = *(int *)pArg;
    cout << "+++A new tcp connection, new connFd = " + to_string(connFd) + "+++" << endl << endl;

    pthread_cleanup_push(closeConnFd, &connFd);

    while (1)
    {
        // Receive message
        char buf[1024] = {0};
        int ret = recv(connFd, buf, sizeof(buf), 0);
        if (ret == 0)
        {
            cout << "Client disconnect!" << endl;
            break;
        }
        else if (ret == -1)
        {
            cerr << "recv" << endl;
            cerr << "errno = " << errno << ", " << strerror(errno) << endl;
            break;
        }
        cout << "~~~http request received for connFd " + to_string(connFd) + "~~~"
             << endl << endl;

        // Parse http request
        string request(buf);
        string requestLine, method, path;
        stringstream requestStream(request);
        getline(requestStream, requestLine);
        stringstream requestLineStream(requestLine);
        requestLineStream >> method >> path;

        string headerLine;
        bool rangeFlag = false;
        string startPosition;
        while (getline(requestStream, headerLine))
        {
            stringstream headerLineStream(headerLine);
            string key;
            headerLineStream >> key;
            if (key == "Range:")
            {
                rangeFlag = true;
                string rangeContent;
                headerLineStream >> rangeContent;
                startPosition = rangeContent.substr(6, rangeContent.size() - 7);
                break;
            }
        }

        path = "./content" + path;
        string response;
        int fd = open(path.c_str(), O_RDWR);

        // Can not find content, send 404
        if (fd == -1)
        {
            response.append("HTTP/1.1 404 Not Found\r\n");
            response.append("Date: ").append(getTimestamp(time(0))).append("\r\n");
            response.append("Content-Length: 13\r\n");
            response.append("Conection: keep-alive\r\n");
            response.append("Content-Type: text/plain\r\n");
            response.append("\r\n");
            response.append("404 Not Found");
            send(connFd, response.c_str(), response.size(), 0);
            cout << "404 Not Found!" << endl
                 << endl;

            continue;
        }

        // Get file size
        struct stat fileInfo;
        fstat(fd, &fileInfo);
        int size = fileInfo.st_size;

        // Check file type
        vector<string> pathWords = splitWithStl(path, "/");
        string fileName = pathWords[pathWords.size() - 1];
        vector<string> fileNameDecompose = splitWithStl(fileName, ".");
        string fileExtension = fileNameDecompose[fileNameDecompose.size() - 1];
        for (char &c : fileExtension) {
            c = tolower(c);
        }
        bool videoType = false;
        if (fileExtension == "mp4" || fileExtension == "webm") {
            videoType = true;
        }

        // Handle normal GET method
        if (method == "GET" && !rangeFlag)
        {
            // Send the whole file
            if (size <= MAX_CHUNKSIZE || !videoType)
            {
                response.append("HTTP/1.1 200 OK\r\n");
                response.append("Date: ").append(getTimestamp(time(0))).append("\r\n");
                response.append("Content-Length: ").append(to_string(size)).append("\r\n");
                response.append("Connection: Keep-Alive\r\n");
                response.append("\r\n");

                bzero(buf, sizeof(buf));
                int dataLen = 0;

                // Send response header
                send(connFd, response.c_str(), response.size(), 0);

                // Send response body (file)
                while (dataLen = read(fd, buf, sizeof(buf)))
                {
                    send(connFd, buf, dataLen, 0);
                    bzero(buf, sizeof(buf));
                }

                cout << "~~~200 OK Response sent for connFd " + to_string(connFd) + "~~~"
                     << endl << endl;
            }
            // If file size is too large and it is a video file, send partial content
            else
            {
                // Get file last-modified info
                time_t lastModTime = fileInfo.st_mtime;
                string lastModTimestamp = getTimestamp(lastModTime);

                response.append("HTTP/1.1 206 Partial Content\r\n");
                response.append("Date: ").append(getTimestamp(time(0))).append("\r\n");
                response.append("Connection: Keep-Alive\r\n");
                response.append("Last-Modified: ").append(lastModTimestamp).append("\r\n");
                response.append("Content-Range: bytes ").append("0-").append(to_string(MAX_CHUNKSIZE - 1)).append("/").append(to_string(size)).append("\r\n");
                response.append("Content-Length: ")
                    .append(to_string(MAX_CHUNKSIZE))
                    .append("\r\n");
                response.append("\r\n");

                // Send response header
                if(send(connFd, response.c_str(), response.size(), 0) == -1) {
                    cerr << "send" << endl;
                    cerr << "errno = " << errno << ", " << strerror(errno) << endl << endl;
                    close(fd);
                    pthread_exit(NULL);
                }

                // Send a file chunk of MAX_CHUNKSIZE bytes
                int bytesLeft = MAX_CHUNKSIZE;
                int dataLen = 0;
                while (dataLen = read(fd, buf, sizeof(buf)))
                {
                    if (dataLen == -1) {
                        cerr << "read" << endl;
                        cerr << "errno = " << errno << ", " << strerror(errno) << endl;
                        close(fd);
                        pthread_exit(NULL);
                    }
                    int ret = send(connFd, buf, dataLen, 0);
                    if (ret == -1)
                    {
                        cerr << "send" << endl;
                        cerr << "errno = " << errno << ", " << strerror(errno) << endl;
                        close(fd);
                        pthread_exit(NULL);
                    }
                    bzero(buf, sizeof(buf));
                    bytesLeft -= dataLen;
                    if (bytesLeft < sizeof(buf))
                    {
                        close(fd);
                        pthread_exit(NULL);
                    }
                }
                read(fd, buf, bytesLeft);
                if(send(connFd, buf, bytesLeft, 0) == -1) {
                    cerr << "send" << endl;
                    cerr << "errno = " << errno << ", " << strerror(errno) << endl << endl;
                    close(fd);
                    pthread_exit(NULL);
                }
                bzero(buf, sizeof(buf));

                cout << "206 Partial Content Response sent!" << endl
                     << endl;
            }
        }
        // Handle GET with Range header
        else if (method == "GET" && rangeFlag)
        {
            // Seek the file descriptor
            lseek(fd, stoi(startPosition), SEEK_SET);

            int bytesLeft = size - stoi(startPosition);
            cout << "Bytes left = " << bytesLeft << endl;
            time_t lastModTime = fileInfo.st_mtime;
            string lastModTimestamp = getTimestamp(lastModTime);
            response.append("HTTP/1.1 206 Partial Content\r\n");
            response.append("Date: ").append(getTimestamp(time(0))).append("\r\n");
            response.append("Conection: Keep-Alive\r\n");
            response.append("Last-Modified: ").append(lastModTimestamp).append("\r\n");
            response.append("Content-Range: bytes ").append(startPosition).append("-");

            // Determine sending size based on remaining file size
            if (bytesLeft <= MAX_CHUNKSIZE)
            {
                cout << "Sending all remaining file..." << endl;

                response.append(to_string(size - 1)).append("/").append(to_string(size)).append("\r\n");
                response.append("Content-Length: ").append(to_string(bytesLeft)).append("\r\n");
                response.append("\r\n");
                if(send(connFd, response.c_str(), response.size(), 0) == -1) {
                    cerr << "send" << endl;
                    cerr << "errno = " << errno << ", " << strerror(errno) << endl << endl;
                    close(fd);
                    pthread_exit(NULL);
                }

                int dataLen = 0;
                int count = 0;
                while (dataLen = read(fd, buf, sizeof(buf)))
                {
                    if(send(connFd, buf, dataLen, 0) == -1) {
                        cerr << "send" << endl;
                        cerr << "errno = " << errno << ", " << strerror(errno) << endl << endl;
                        close(fd);
                        pthread_exit(NULL);
                    }
                    bzero(buf, sizeof(buf));
                    count += dataLen;
                }
                cout << "Remaining file sent!" << endl;
                cout << "Sent bytes count = " << count << endl
                     << endl;
            }
            else
            {
                cout << "Sending next chunk of file..." << endl;

                int startIndex = stoi(startPosition);
                response.append(to_string(startIndex + MAX_CHUNKSIZE - 1)).append("/").append(to_string(size)).append("\r\n");
                response.append("Content-Length: ").append(to_string(MAX_CHUNKSIZE)).append("\r\n");
                response.append("\r\n");
                if (send(connFd, response.c_str(), response.size(), 0) == -1) {
                    cerr << "send" << endl;
                    cerr << "errno = " << errno << ", " << strerror(errno) << endl << endl;
                    close(fd);
                    pthread_exit(NULL);
                }

                int bytesToSend = MAX_CHUNKSIZE;
                int dataLen = 0;
                cout << response;
                while (dataLen = read(fd, buf, sizeof(buf)))
                {
                    int ret = send(connFd, buf, dataLen, 0);
                    if (ret == -1)
                    {
                        cerr << "send" << endl;
                        cerr << "errno = " << errno << ", " << strerror(errno) << endl << endl;
                        close(fd);
                        pthread_exit(NULL);
                    }
                    bzero(buf, sizeof(buf));
                    bytesToSend -= dataLen;
                    if (bytesToSend < sizeof(buf))
                    {
                        break;
                    }
                }
                read(fd, buf, bytesToSend);
                if (send(connFd, buf, bytesToSend, MSG_NOSIGNAL) == -1) {
                    cerr << "send" << endl;
                    cerr << "errno = " << errno << ", " << strerror(errno) << endl << endl;
                    close(fd);
                    pthread_exit(NULL);
                }
                bzero(buf, sizeof(buf));

                cout << "Next chunk sent!" << endl
                     << endl;
            }
        }
        close(fd);
    }
    close(connFd);
    pthread_cleanup_pop(1);
    
}


int main(int argc, char *argv[])
{
    // Ignore SIGPIPE signal
    signal(SIGPIPE, SIG_IGN);

    // Get port number from command line arg
    if (argc != 2) {
        cout << "Number of input arguments is wrong!" << endl;
        return -1;
    }
    string portStr = argv[1];

    // Create a socket
    int sfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sfd == -1)
    {
        cerr << "socket" << endl;
        return -1;
    }

    // Set sockaddr_in
    struct sockaddr_in myAddr;
    bzero(&myAddr, sizeof(struct sockaddr));
    myAddr.sin_family = AF_INET;
    myAddr.sin_port = htons(stoi(portStr));
    myAddr.sin_addr.s_addr = htonl(INADDR_ANY);

    // Setsockopt
    int optval = 1;
    setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, (const void *)&optval, sizeof(optval));

    // Bind
    if (bind(sfd, (struct sockaddr *)&myAddr, sizeof(struct sockaddr)) == -1)
    {
        cerr << "bind" << endl;
        close(sfd);
        return -1;
    }

    // Listen
    if (listen(sfd, 20) == -1)
    {
        cerr << "listen" << endl;
        close(sfd);
        return -1;
    }

    while (1)
    {
        // Accept
        struct sockaddr_in clientAddr;
        bzero(&clientAddr, sizeof(struct sockaddr));
        int addrlen = sizeof(struct sockaddr);

        int connFd = accept(sfd, (struct sockaddr *)&clientAddr, (socklen_t *)&addrlen);
        if (connFd == -1)
        {
            cerr << "connect" << endl;
            close(sfd);
            return -1;
        }

        // Set sending buffer size as 100kB
        socklen_t sendbuflen = 0;
        socklen_t len = sizeof(sendbuflen);
        sendbuflen = 102400;
        setsockopt(connFd, SOL_SOCKET, SO_SNDBUF, (void *)&sendbuflen, len);

        // Create a child thread to handle each tcp connection
        pthread_t childThreadId;
        pthread_create(&childThreadId, NULL, threadFunc, &connFd);
        
        // Pause for a while to make sure new connFd is different
        usleep(500);
    }
}